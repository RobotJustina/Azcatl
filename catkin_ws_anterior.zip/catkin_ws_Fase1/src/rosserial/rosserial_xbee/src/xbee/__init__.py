"""
XBee package initalization file

By Paul Malmsten, 2010
pmalmsten@gmail.com
"""

from xbee.ieee import XBee
from xbee.zigbee import ZigBee
